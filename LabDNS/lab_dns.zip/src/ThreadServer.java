import java.io.IOException;
import java.lang.reflect.Array;
import java.math.BigInteger;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;

public class ThreadServer implements Runnable {
    private Integer nThreadServer;
    byte[] input = new byte[65535];
    private Integer delay;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMddHHmm");
    private DatagramSocket socket;
    static Logger LOGGER = Logger.getLogger("Server");

    public ThreadServer(Integer id, DatagramSocket socket, Integer delay) {
        this.nThreadServer = id;
        this.socket = socket;
        this.delay = delay;
    }

    @Override
    public void run() {
        byte[] input = new byte[65535];
        DatagramPacket receivePacket = null;
        while (true) {
            try {
                receivePacket = new DatagramPacket(input, input.length);
                socket.receive(receivePacket);
                InetAddress c_address = receivePacket.getAddress();
                int port_c = receivePacket.getPort();
                String mess = new String(receivePacket.getData());
                LOGGER.info("LEGIBLE: "+filterPrintableChars(receivePacket.getData(), receivePacket.getLength()));
                LOGGER.info("HEXADECIMAL: "+bytesToHex(receivePacket.getData(),
                        receivePacket.getLength()));
                byte[] query = handleQuery(receivePacket.getData(), receivePacket.getLength());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    private static String bytesToHex(byte[] bytes, int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(String.format("%x ", bytes[i]));
        }
        return sb.toString().trim();
    }

    private static String filterPrintableChars(byte[] data, int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = (char) data[i];
            if (c >= 32 && c <= 126) { // Imprimible ASCII range
                sb.append(c);
            } else {
                sb.append('.');
            }
        }
        return sb.toString();
    }

    private static byte[] handleQuery(byte[] query, int queryLength){

        byte[] response = new byte[512];

        // Copiar el identificador de la consulta a la respuesta
        response[0] = query[0];
        response[1] = query[1];

        // Flags: Respuesta estándar, no autoritativa, no truncada, sin errores
        response[2] = (byte) 0x81;
        response[3] = (byte) 0x80;

        // Número de preguntas: 1
        response[4] = 0x00;
        response[5] = 0x01;

        // Número de respuestas: 1
        response[6] = 0x00;
        response[7] = 0x01;

        // Número de registros de autoridad: 0
        response[8] = 0x00;
        response[9] = 0x00;
        
        return response;
    }
}
